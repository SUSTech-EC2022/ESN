a = 0.5

if a==0.5:
    result = 10
else:
    result = 1
print(result)